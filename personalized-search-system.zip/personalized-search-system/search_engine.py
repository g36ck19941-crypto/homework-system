import json
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os

class SearchEngine:
    def __init__(self):
        """初始化搜索引擎"""
        # 加载文档数据
        with open('data/documents.json', 'r', encoding='utf-8') as f:
            self.documents = json.load(f)
        
        # 用户行为文件
        self.behavior_file = 'data/user_behavior.json'
        
        # 构建文档索引
        self.build_index()
        
        # 初始化TF-IDF向量器
        self.vectorizer = TfidfVectorizer()
        self.doc_vectors = self.vectorizer.fit_transform([
            f"{doc['title']} {doc['content']} {' '.join(doc['tags'])}"
            for doc in self.documents
        ])
    
    def build_index(self):
        """构建简单的倒排索引"""
        self.index = {}
        for doc in self.documents:
            # 为标题、内容和标签建立索引
            text_fields = [doc['title'], doc['content']] + doc['tags']
            for field in text_fields:
                words = field.lower().split()
                for word in words:
                    if word not in self.index:
                        self.index[word] = []
                    if doc['id'] not in self.index[word]:
                        self.index[word].append(doc['id'])
    
    def load_user_behavior(self):
        """加载用户行为数据"""
        if os.path.exists(self.behavior_file):
            with open(self.behavior_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def update_user_preference(self, user_id, doc_id):
        """更新用户偏好"""
        behavior_data = self.load_user_behavior()
        
        if user_id not in behavior_data:
            behavior_data[user_id] = {
                'clicks': [],
                'preferences': {}
            }
        
        # 找到被点击的文档
        clicked_doc = next((d for d in self.documents if d['id'] == doc_id), None)
        if not clicked_doc:
            return
        
        # 更新用户偏好（基于标签）
        preferences = behavior_data[user_id].get('preferences', {})
        for tag in clicked_doc['tags']:
            preferences[tag] = preferences.get(tag, 0) + 1
        
        # 更新category偏好
        category = clicked_doc.get('category', '')
        if category:
            preferences[category] = preferences.get(category, 0) + 1
        
        behavior_data[user_id]['preferences'] = preferences
        
        # 保存更新
        with open(self.behavior_file, 'w', encoding='utf-8') as f:
            json.dump(behavior_data, f, ensure_ascii=False, indent=2)
    
    def get_user_preferences(self, user_id):
        """获取用户偏好"""
        behavior_data = self.load_user_behavior()
        if user_id in behavior_data:
            return behavior_data[user_id].get('preferences', {})
        return {}
    
    def search(self, query, user_id):
        """执行个性化搜索"""
        # 基础搜索：TF-IDF相似度
        query_vector = self.vectorizer.transform([query])
        similarities = cosine_similarity(query_vector, self.doc_vectors).flatten()
        
        # 获取用户偏好
        user_preferences = self.get_user_preferences(user_id)
        
        # 计算个性化分数
        personalized_scores = []
        for i, doc in enumerate(self.documents):
            base_score = similarities[i]
            personal_score = 0
            
            # 基于用户偏好调整分数
            for tag in doc['tags']:
                personal_score += user_preferences.get(tag, 0) * 0.1
            
            if doc.get('category') in user_preferences:
                personal_score += user_preferences.get(doc['category'], 0) * 0.2
            
            # 组合分数（70%基础相似度 + 30%个性化分数）
            final_score = 0.7 * base_score + 0.3 * min(personal_score, 1.0)
            
            personalized_scores.append({
                'doc': doc,
                'base_score': float(base_score),
                'personal_score': float(personal_score),
                'final_score': float(final_score)
            })
        
        # 按最终分数排序
        personalized_scores.sort(key=lambda x: x['final_score'], reverse=True)
        
        # 格式化结果
        results = []
        for i, item in enumerate(personalized_scores):
            if item['final_score'] > 0:  # 只返回有相关性的结果
                doc = item['doc'].copy()
                doc['rank'] = i + 1
                doc['base_score'] = item['base_score']
                doc['personal_score'] = item['personal_score']
                doc['final_score'] = item['final_score']
                results.append(doc)
        
        return results[:10]  # 返回前10个结果