class SearchApp {
    constructor() {
        this.currentUser = 'default_user';
        this.initEventListeners();
        this.loadDocuments();
        this.loadUserPreferences();
    }

    initEventListeners() {
        // 搜索按钮点击事件
        document.getElementById('search-btn').addEventListener('click', () => {
            this.performSearch();
        });

        // 回车键搜索
        document.getElementById('search-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performSearch();
            }
        });

        // 用户切换
        document.getElementById('user-select').addEventListener('change', (e) => {
            this.currentUser = e.target.value;
            this.loadUserPreferences();
        });

        // 重置用户行为
        document.getElementById('reset-btn').addEventListener('click', () => {
            this.resetUserBehavior();
        });
    }

    async performSearch() {
        const query = document.getElementById('search-input').value.trim();
        if (!query) {
            alert('请输入搜索关键词');
            return;
        }

        try {
            const response = await fetch('/search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: query,
                    user_id: this.currentUser
                })
            });

            const data = await response.json();
            this.displayResults(data);
        } catch (error) {
            console.error('搜索失败:', error);
            alert('搜索失败，请重试');
        }
    }

    async recordClick(docId) {
        try {
            await fetch('/record_click', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: this.currentUser,
                    doc_id: docId
                })
            });

            // 更新用户偏好显示
            this.loadUserPreferences();
        } catch (error) {
            console.error('记录点击失败:', error);
        }
    }

    async loadUserPreferences() {
        try {
            const response = await fetch(`/user_behavior/${this.currentUser}`);
            const data = await response.json();
            
            const preferencesDiv = document.getElementById('user-preferences');
            if (data.preferences && Object.keys(data.preferences).length > 0) {
                let html = '';
                for (const [tag, score] of Object.entries(data.preferences)) {
                    html += `<span class="preference-tag">${tag}: ${score}</span>`;
                }
                preferencesDiv.innerHTML = html;
            } else {
                preferencesDiv.innerHTML = '<span style="color: #999;">暂无偏好数据，点击搜索结果来记录您的兴趣</span>';
            }
        } catch (error) {
            console.error('加载用户偏好失败:', error);
        }
    }

    async loadDocuments() {
        try {
            const response = await fetch('/documents');
            const documents = await response.json();
            this.displayDocuments(documents);
        } catch (error) {
            console.error('加载文档失败:', error);
        }
    }

    async resetUserBehavior() {
        if (confirm(`确定要重置用户 ${this.currentUser} 的行为数据吗？`)) {
            try {
                const response = await fetch(`/reset_behavior/${this.currentUser}`);
                const data = await response.json();
                
                if (data.success) {
                    alert('用户行为已重置');
                    this.loadUserPreferences();
                    // 清空搜索结果
                    document.getElementById('search-results').innerHTML = '';
                    document.getElementById('results-count').textContent = '0';
                }
            } catch (error) {
                console.error('重置失败:', error);
            }
        }
    }

    displayResults(data) {
        const resultsDiv = document.getElementById('search-results');
        const countSpan = document.getElementById('results-count');
        
        if (data.error) {
            resultsDiv.innerHTML = `<div class="error">${data.error}</div>`;
            countSpan.textContent = '0';
            return;
        }

        if (data.results.length === 0) {
            resultsDiv.innerHTML = '<div class="no-results">未找到相关结果</div>';
            countSpan.textContent = '0';
            return;
        }

        countSpan.textContent = data.results.length;
        
        let html = '';
        data.results.forEach(result => {
            html += `
                <div class="result-item" data-doc-id="${result.id}">
                    <div class="result-header">
                        <a href="#" class="result-title" onclick="app.handleDocClick(${result.id}, '${result.title}')">
                            ${result.title}
                        </a>
                        <div class="result-score">
                            <div class="score-item">
                                <span class="score-label">基础分</span>
                                <span class="score-value">${result.base_score.toFixed(3)}</span>
                            </div>
                            <div class="score-item">
                                <span class="score-label">个性化分</span>
                                <span class="score-value">${result.personal_score.toFixed(3)}</span>
                            </div>
                            <div class="score-item">
                                <span class="score-label">最终分</span>
                                <span class="score-value">${result.final_score.toFixed(3)}</span>
                            </div>
                        </div>
                    </div>
                    <div class="result-content">
                        ${result.content.substring(0, 150)}...
                    </div>
                    <div class="result-tags">
                        <span class="tag category">${result.category}</span>
                        ${result.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                    </div>
                    <div class="result-meta">
                        排名: ${result.rank} | ID: ${result.id}
                    </div>
                </div>
            `;
        });
        
        resultsDiv.innerHTML = html;
    }

    displayDocuments(documents) {
        const listDiv = document.getElementById('documents-list');
        let html = '';
        
        documents.forEach(doc => {
            html += `
                <div class="document-card">
                    <h4>${doc.title}</h4>
                    <p>${doc.content.substring(0, 100)}...</p>
                    <div class="result-tags">
                        <span class="tag category">${doc.category}</span>
                        ${doc.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                    </div>
                </div>
            `;
        });
        
        listDiv.innerHTML = html;
    }

    handleDocClick(docId, title) {
        // 记录用户点击
        this.recordClick(docId);
        
        // 显示文档详情
        alert(`查看文档: ${title}\n\n用户行为已记录，系统将根据您的兴趣调整未来的搜索结果。`);
        
        return false; // 阻止默认链接行为
    }
}

// 初始化应用
const app = new SearchApp();