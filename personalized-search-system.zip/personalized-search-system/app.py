from flask import Flask, render_template, request, jsonify
import json
import os
from search_engine import SearchEngine
from datetime import datetime

app = Flask(__name__)

# 初始化搜索引擎
search_engine = SearchEngine()

# 加载文档数据
with open('data/documents.json', 'r', encoding='utf-8') as f:
    documents = json.load(f)

# 用户行为文件路径
BEHAVIOR_FILE = 'data/user_behavior.json'

# 确保用户行为文件存在
if not os.path.exists(BEHAVIOR_FILE):
    with open(BEHAVIOR_FILE, 'w', encoding='utf-8') as f:
        json.dump({}, f)

def load_user_behavior():
    with open(BEHAVIOR_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_user_behavior(behavior):
    with open(BEHAVIOR_FILE, 'w', encoding='utf-8') as f:
        json.dump(behavior, f, ensure_ascii=False, indent=2)

@app.route('/')
def index():
    """渲染主页"""
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    """处理搜索请求"""
    data = request.get_json()
    query = data.get('query', '')
    user_id = data.get('user_id', 'default_user')
    
    if not query:
        return jsonify({'error': '查询不能为空'})
    
    # 执行搜索（包含个性化排序）
    results = search_engine.search(query, user_id)
    
    return jsonify({
        'query': query,
        'results': results,
        'total': len(results)
    })

@app.route('/record_click', methods=['POST'])
def record_click():
    """记录用户点击行为"""
    data = request.get_json()
    user_id = data.get('user_id', 'default_user')
    doc_id = data.get('doc_id')
    
    if not doc_id:
        return jsonify({'error': '文档ID不能为空'})
    
    # 加载用户行为
    behavior_data = load_user_behavior()
    
    # 初始化用户行为记录
    if user_id not in behavior_data:
        behavior_data[user_id] = {
            'clicks': [],
            'searches': [],
            'preferences': {}
        }
    
    # 记录点击
    click_record = {
        'doc_id': doc_id,
        'timestamp': datetime.now().isoformat()
    }
    behavior_data[user_id]['clicks'].append(click_record)
    
    # 保存更新
    save_user_behavior(behavior_data)
    
    # 更新用户偏好
    search_engine.update_user_preference(user_id, doc_id)
    
    return jsonify({'success': True})

@app.route('/documents')
def get_documents():
    """获取所有文档列表"""
    return jsonify(documents)

@app.route('/user_behavior/<user_id>')
def get_user_behavior(user_id):
    """获取用户行为数据"""
    behavior_data = load_user_behavior()
    return jsonify(behavior_data.get(user_id, {}))

@app.route('/reset_behavior/<user_id>')
def reset_behavior(user_id):
    """重置用户行为数据"""
    behavior_data = load_user_behavior()
    if user_id in behavior_data:
        behavior_data[user_id] = {
            'clicks': [],
            'searches': [],
            'preferences': {}
        }
        save_user_behavior(behavior_data)
    return jsonify({'success': True})

if __name__ == '__main__':
    app.run(debug=True, port=5000)